/*
*
* @autor Carmen Varela Iglesias
* @autor Zhou Zhihui
*
* */

module Making.social {
    requires java.sql;
    requires java.desktop;
    requires jcalendar;
    requires jdk.jdi;
}